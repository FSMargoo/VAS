<div align="center">
    <h1 align="center">VAS : Visible Angle Shading</h1>

<p align="center">
        <a href="mailto:qiuzhengyu@siggraph.org"><strong>ZhengYu Qiu</strong></a>
  </p>
</div>

A fast way to render the 2D lighting in real-time.

![](./readme/banner.png)